package com.example.moviereviewzproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieReviewzprojectApplication {

    public static void main(String[] args) {
        SpringApplication.run(MovieReviewzprojectApplication.class, args);
    }

}

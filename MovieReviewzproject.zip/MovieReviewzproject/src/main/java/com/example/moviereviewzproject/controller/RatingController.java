package com.example.moviereviewzproject.controller;

import com.example.moviereviewzproject.model.Rating;
import com.example.moviereviewzproject.repository.RatingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/ratings")
public class RatingController {

    @Autowired
    private RatingRepository ratingRepository;
    @GetMapping
    public ResponseEntity<List<Rating>> getAllRatings() {
        List<Rating> ratings = ratingRepository.findAll();
        if (ratings.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(ratings, HttpStatus.OK);
    }
    @PostMapping
    public ResponseEntity<Rating> createRating(@RequestBody Rating rating) {
        Rating createdRating = ratingRepository.save(rating);
        return new ResponseEntity<>(createdRating, HttpStatus.CREATED);
    }


//movie
//    @GetMapping("/user/{userId}")
//    public ResponseEntity<List<Rating>> getRatingsByUser(@PathVariable("userId") long user_id) {
//        List<Rating> ratings = ratingRepository.findByUser_id(user_id);
//        if (ratings.isEmpty()) {
//            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//        }
//        return new ResponseEntity<>(ratings, HttpStatus.OK);
//    }
//    @GetMapping("/{id}")
//    public ResponseEntity<Rating> getRatingById(@PathVariable("id") int id) {
//        Optional<Rating> rating = ratingRepository.findById(id);
//        return rating.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
//                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
//    }
    @PutMapping("/{id}")
    public ResponseEntity<Rating> updateRating(@PathVariable("id") int id, @RequestBody Rating updatedRating) {
        Optional<Rating> existingRatingOpt = ratingRepository.findById(id);
        if (existingRatingOpt.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        Rating existingRating = existingRatingOpt.get();
        existingRating.setRatingValue(updatedRating.getRatingValue());
        Rating savedRating = ratingRepository.save(existingRating);
        return new ResponseEntity<>(savedRating, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteRating(@PathVariable("id") int id) {
        try {
            if (ratingRepository.existsById(id)) {
                ratingRepository.deleteById(id);
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
//    @GetMapping("/movie/{movieId}/average")
//    public ResponseEntity<Double> getAverageRating(@PathVariable("movieId") int movieId) {
//        Double averageRating = ratingRepository.findAverageRatingByMovieId(movieId);
//        if (averageRating == null) {
//            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//        }
//        return new ResponseEntity<>(averageRating, HttpStatus.OK);
//    }
//}

package com.example.moviereviewzproject.repository;

import com.example.moviereviewzproject.model.Movie;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MovieRepository extends JpaRepository<Movie, Integer> {
    List<Movie> findByTitleContainingIgnoreCase(String title);

    @Query("SELECT m FROM Movie m WHERE m.maturityRating = ?1")
    List<Movie> findByMaturityRating(String maturityRating);

    @Query("SELECT m FROM Movie m WHERE m.genre.genreId = ?1")
    List<Movie> findByGenreId(Integer genreId);

    List<Movie> findByDescriptionContainingIgnoreCase(String description);
}

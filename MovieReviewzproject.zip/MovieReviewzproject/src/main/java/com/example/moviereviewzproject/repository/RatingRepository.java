package com.example.moviereviewzproject.repository;

import com.example.moviereviewzproject.model.Rating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RatingRepository extends JpaRepository<Rating, Integer> {

    @Query("SELECT r.movie FROM Rating r WHERE r.movie.movieId = ?1")
    List<Rating> findByMovieId(int movieID);    List<Rating> findByUser_id(long user_id);
//    List<Rating> findByShowId(int showId);
    @Query("SELECT AVG(r.ratingValue) FROM Rating r WHERE r.movie.movieId = ?1")
    Double findAverageRatingByMovieId(int movieId);

    Rating findByUserIdAndMovie_MovieId(long user_id, int movieId);
}

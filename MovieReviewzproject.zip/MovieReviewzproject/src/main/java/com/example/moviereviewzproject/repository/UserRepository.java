package com.example.moviereviewzproject.repository;

import com.example.moviereviewzproject.model.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<Users, Long> {

    // Find user by email
    List<Users> findByEmail(String email);



    // Find user by ID
//    Optional<User> findById(Long userId);
}

package com.example.moviereviewzproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieReviewzprojectApplicationTests {

    @Test
    void contextLoads() {
    }

}
